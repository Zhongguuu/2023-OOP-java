package com.editor;

import com.editor.utils.FileItem;
import javafx.scene.control.TreeItem;

import java.util.TreeMap;

public class Data {
    //这是记录公共数据
    public static String curuser;

    //当前文件路径
    public static String curpath;

    //当前文件名
    public static String curfile;

    public static FileItem curFileItem;


}
